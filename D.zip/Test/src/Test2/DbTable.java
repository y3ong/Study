package Test2;

public class DbTable {

	// 테이블 정의서를 보고 필드(변수)를 선언하시오.

	private int 번호;
	private String 상품명;
	private int 가격;
	private boolean 반품여부;
	
	public int get번호() {
		return 번호;
	}
	public void set번호(int 번호) {
		this.번호 = 번호;
	}
	public String get상품명() {
		return 상품명;
	}
	public void set상품명(String 상품명) {
		this.상품명 = 상품명;
	}
	public int get가격() {
		return 가격;
	}
	public void set가격(int 가격) {
		this.가격 = 가격;
	}
	public boolean is반품여부() {
		return 반품여부;
	}
	public void set반품여부(boolean 반품여부) {
		this.반품여부 = 반품여부;
	}
	@Override
	public String toString() {
		return "DbTable [번호=" + 번호 + ", 상품명=" + 상품명 + ", 가격=" + 가격 + ", 반품여부=" + 반품여부 + "]";
	}
	
	
}
