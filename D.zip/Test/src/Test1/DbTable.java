package Test1;

public class DbTable {

	// 테이블 정의서를 보고 필드(변수)를 선언하시오.

	private int no;
	private String menu;
	private String type;
	private int price;
	private boolean delYn;
	
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public String getMenu() {
		return menu;
	}
	public void setMenu(String menu) {
		this.menu = menu;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public boolean isDelYn() {
		return delYn;
	}
	public void setDelYn(boolean delYn) {
		this.delYn = delYn;
	}
	@Override
	public String toString() {
		return "DbTable [no=" + no + ", menu=" + menu + ", type=" + type + ", price=" + price + ", delYn=" + delYn
				+ "]";
	}
	
	
	
}
