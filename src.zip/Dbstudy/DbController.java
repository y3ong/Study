package Dbstudy;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DbController {

	private String driver;
	private String 주소;
	private String 사용자;
	private String 비밀번호;
	
	private String 테이블 = "create or replace table"
						+ " 명단 ("
						+ " 번호 int,"
						+ " 이름 varchar(50),"
						+ " 성별 varchar(50),"
						+ " 특징 varchar(50),"
						+ " 해적단 varchar(50),"
						+ " 역할 varchar(50)"
						+ " )";
	private String 입력 = "insert into 명단 value (?,?,?,?,?,?)"; // parameter 의 값이 매번 바뀌어서 ?로 처리하여 사용함
	private String 읽기 = "select * from 명단";
	private String 수정 = "update 명단 set 역할 = ? where 번호 = ?";
	private String 삭제 = "delete from 명단 where 번호 = ?";
		
	public DbController(String driver, String 주소, String 사용자, String 비밀번호) { 
		this.driver = driver;
		this.주소 = 주소;
		this.사용자 = 사용자;
		this.비밀번호 = 비밀번호; // 재사용하려고 주소를 메인 메소드로 보냄
		시작(); // method
	}
	
		private void 시작() {
			try {
			Class.forName(driver);
			Connection conn = DriverManager.getConnection(주소, 사용자, 비밀번호);
				기능제어(conn); // 기능제어 부분에 담긴 메소드 호출
				conn.close();
			} catch (ClassNotFoundException e) { // 설정한 라이브러리 확인이 가능, 예외처리 도와줌
				e.printStackTrace(); // 에러코드
			} catch (SQLException e) {
				e.printStackTrace();
			} 
			
		}
		
		// DML 기능 > CRUD
		// 1단계 데이터 넣기 insert
		// sql = 데이터생성();
		// cud기능(sql, conn);
		
		private void 기능제어(Connection conn) {
			if(테이블생성(테이블, conn)) {
				List list = 데이터생성(); // List<DataDto>로 사용가능
				for(int i = 0; i < list.size(); i++) { // 리스트의 크기만큼 반복
					cud기능(입력,conn, (DataDto) list.get(i), "I");
					// 실행되면 cud기능으로 감
				} 데이터읽기(읽기, conn);
				
				DataDto data = new DataDto();
				data.set번호(10);
				data.set역할("광대");
				cud기능(수정, conn, data, "U");
				데이터읽기(읽기, conn);
				
				data = new DataDto();
				data.set번호(10);
				cud기능(삭제, conn, data, "D");
				데이터읽기(읽기, conn);
				
		} else {
			System.out.println("테이블 생성 실패");
		}
	}
//			String sql="create or replace table 명단 (";
//			sql += " 번호	 int,";
//			sql += " 이름 varchar(50),";
//			sql += " 성별 varchar(50),";
//			sql += " 특징	 varchar(50),";
//			sql += " 해적단 varchar(50),";
//			sql += " 역할 varchar(50) ";
//			sql += " )";

				// 읽기
//				데이터읽기("select * from 명단", conn);
//				
//				// 수정
//				sql = "update 명단 set  역할 = '광대' where 번호 = 1"; -> where은 조건식
//				cud기능 (sql, conn);
//				데이터읽기("select * from 명단", conn);
//				
//				// 삭제
//				sql = "delete from 명단 where 번호 = 1";
//				cud기능 (sql, conn);
//				데이터읽기("select * from 명단", conn);
				
		
		private List 데이터생성() {
			List list = new ArrayList<DataDto>();
			
			DataDto data = new DataDto(); // 데이터를 담기 위한 객체 생성
			data.set번호(1);
			data.set이름("몽키 D 루피");
			data.set성별("남자");
			data.set특징("고무고무 열매");
			data.set해적단("밀짚모자");
			data.set역할("선장");
			list.add(data);
			
			data = new DataDto(); // 참조자료형, 구조이기때문에 new로 주소값을 새로 설정하여 각각의 값을 설정
			data.set번호(2);
			data.set이름("롤로노아 조로");
			data.set성별("남자");
			data.set특징("삼도류");
			data.set해적단("밀짚모자");
			data.set역할("부선장");
			list.add(data);
			
			data = new DataDto();
			data.set번호(3);
			data.set이름("상디");
			data.set성별("남자");
			data.set특징("요리사");
			data.set해적단("밀짚모자");
			data.set역할("요리사");
			list.add(data);
			
			data = new DataDto();
			data.set번호(4);
			data.set이름("나미");
			data.set성별("여자");
			data.set특징("항해사");
			data.set해적단("밀짚모자");
			data.set역할("항해사");
			list.add(data);
			
			data = new DataDto();
			data.set번호(5);
			data.set이름("우솝");
			data.set성별("남자");
			data.set특징("사격");
			data.set해적단("밀짚모자");
			data.set역할("저격수");
			list.add(data);
			
			data = new DataDto();
			data.set번호(6);
			data.set이름("토니토니 쵸파");
			data.set성별("미정");
			data.set특징("사람사람 열매");
			data.set해적단("밀짚모자");
			data.set역할("의사");
			list.add(data);
			
			data = new DataDto();
			data.set번호(7);
			data.set이름("니코 로빈");
			data.set성별("여자");
			data.set특징("꽃꽃 열매");
			data.set해적단("밀짚모자");
			data.set역할("고고학자");
			list.add(data);
			
			data = new DataDto();
			data.set번호(8);
			data.set이름("프랑키");
			data.set성별("남자");
			data.set특징("사이보그");
			data.set해적단("밀짚모자");
			data.set역할("조선공");
			list.add(data);
			
			data = new DataDto();
			data.set번호(9);
			data.set이름("브록");
			data.set성별("남자");
			data.set특징("연주자");
			data.set해적단("밀짚모자");
			data.set역할("선원");
			list.add(data);
			
			data = new DataDto();
			data.set번호(10);
			data.set이름("버기");
			data.set성별("남자");
			data.set특징("동강동강 열매");
			data.set해적단("버기");
			data.set역할("선장");
			list.add(data);
			
			
//			String sql = "insert into 명단 value (";
//			
//			sql += data.get번호();
//			sql += ",'"+data.get이름()+"'";
//			sql += ",'"+data.get성별()+"'";
//			sql += ",'"+data.get특징()+"'";
//			sql += ",'"+data.get해적단()+"'";
//			sql += ",'"+data.get역할()+"'";
//			
//			sql += ")";
			return list;
		}
		
		private boolean 테이블생성(String sql, Connection conn) {
			System.out.println(sql);
			try {
				PreparedStatement ps = conn.prepareStatement(sql);
				ps.execute();
				ps.close();
				return true; // < 끝난 시점 발생 : 성공
			} catch (SQLException e) {
				e.printStackTrace();
			}
				return false; // < 끝난 시점 발생 : 실패
			}
		
		
		private void 데이터읽기(String sql, Connection conn) {
				System.out.println(sql);
				try {
				PreparedStatement ps = conn.prepareStatement(sql);
				ResultSet rs = ps.executeQuery(); // Select문 사용시 executeQuery를 통해 결과값을 리턴받을 수 있음
				
				while(rs.next()) { // while 문 조건식의 값이 참이면 실행
					DataDto data = new DataDto();
					data.set번호(rs.getInt("번호"));
					data.set이름(rs.getString("이름"));
					data.set성별(rs.getString("성별"));
					data.set특징(rs.getString("특징"));
					data.set해적단(rs.getString("해적단"));
					data.set역할(rs.getString("역할"));
					System.out.println(data); // DataDto에 대한 객체
				}
				rs.close();
				ps.close(); // memory 공간을 위해 close
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
//														String type : insert or update or delete 를 구분
		private void cud기능(String sql, Connection conn, DataDto data, String type) {
//			System.out.println(sql);
			try {
			PreparedStatement ps = conn.prepareStatement(sql);
			
			if("I".equals(type)) { // ?의 값을 입력하기 위해 정리
				ps.setInt(1, data.get번호());
				ps.setString(2, data.get이름());
				ps.setString(3, data.get성별());
				ps.setString(4, data.get특징());
				ps.setString(5, data.get해적단());
				ps.setString(6, data.get역할());
			} else if("U".equals(type)) {
				ps.setString(1, data.get역할());
				ps.setInt(2,  data.get번호());
			} else if("D".equals(type)) {
				ps.setInt(1, data.get번호());
			}
			
			int result = ps.executeUpdate(); // INSERT, UPDATE or DELETE만 가능한 명령어
			System.out.println(result);
			ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}



