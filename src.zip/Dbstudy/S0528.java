package Dbstudy;

import java.util.ArrayList;
import java.util.List;

public class S0528 {

	public static void main(String[] args) {
		
		String driver = "org.mariadb.jdbc.Driver";
		String 주소 = "jdbc:mariadb://localhost:3306/ye";
		String 사용자 = "root";
		String 비밀번호 = "1004";
		
		new DbController(driver, 주소, 사용자, 비밀번호);

		/*	 	이름			성별			특징			해적단		역할
		 * 	 몽키 D 루피		남자		 고무고무 열매     밀짚모자		선장
		 * 	 롤로노아 조로		남자		   삼도류		    밀짚모자		부선장
		 * 		상디			남자		   요리사		 	밀짚모자		요리사
		 * 		나미 			여자 		   항해사			밀짚모자		항해사
		 * 		우솝			남자			사격			밀짚모자 		저격수
		 *   토니토니 쵸파		미정		 사람사람 열매		밀짚모자		의사
		 *    니코 로빈		여자		  꽃꽃 열매		밀짚모자		고고학자
		 *      프랑키		남자		  사이보그			밀짚모자		조선공
		 *  	브록			남자		   연주자			밀짚모자		선원
		 *  	버기			나마		 동강동강 열매		 버기 		광대
		 */
	
	}

}
