package S0524;

public abstract class Study02_1 {
	// 추상적인 method를 쓰려면 class도 추상적이어야 됨
	// abstract 사용
	void 함수() {
		System.out.println("함수");
		
	}
	
	abstract void 함수2();
}
