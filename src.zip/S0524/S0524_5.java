package S0524;

public class S0524_5 {
	
	private int a;

		S0524_5(){
//			System.out.println(111111);
		}
		// 생성자(class)도 method처럼 매개변수를 이용하게 되면 여러개 쓸 수 있음
		// 생성자 () 가로안이 비어있는게 기본 생성자, 가로안에 무언가가 적혀있을 때 무언가를 받음
		
		S0524_5(int a){
			System.out.println(a);
			this.a = a;
		}
		
		void b() {
//			System.out.println(a);
		}
}
