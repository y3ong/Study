package S0524;

public class Study04 {

	public static void main(String[] args) {
		
		new Study04_1(3, 6);
		
	}
	
	
//	static void 구구단(int a) {
//		단(1);
//		
//	}
//
//	// 구구단 만들기
//	
// 	static void 단(int a) {s
//		
//		for(; a <= 9 ; a++) {
//			System.out.println(a+"단");
//		 계산(a);
//		 
//			
//		}
//	}
//	
//	static void 계산(int a) {
//		for(int i = 1; i <=9 ; i++) {
//			System.out.println(a+"*"+i+"="+(a*i));
//			
//		}
//		
//	}
	
}
