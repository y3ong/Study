package S0524;

public class S0524_1 {

	static int b = 0; 
	
	public static void main(String[] args) {
	
		a();
	}

	
	static void a() {
		
		
		if(b<5) {
			System.out.println("안녕!" + b);
			b++;
			a(); }
		
	// for 문 처럼 반복문같이 사용가능
	// 하지만 종료시점을 만들어줘야 함!

	}
}
