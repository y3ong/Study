package S0524;

public class Study03_1 {

	Study03_1() {}
	Study03_1(int a){this.a=a;}
	
	
	int a;
	void 함수() {System.out.println(a);
		
	}
}
