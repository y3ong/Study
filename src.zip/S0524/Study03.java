package S0524;

public class Study03 {

	public static void main(String[] args) {
		
		Study03_2 s3 = new Study03_2(); // new 객체 중요! 사용시에 변수명.method명();
		s3.함수();
		s3.함수2();


	}

}
