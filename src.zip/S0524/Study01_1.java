package S0524;

public class Study01_1 {

	void 함수() {
		
	}

		
	}

