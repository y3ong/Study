package S0524;

public class Study01_2 {

	static int a = 10;
	static void 함수() {
		
	}
}
