package Study;

public class S0517 {

	public static void main(String[] args) {
		
		boolean 논리값 = true;
		
		/*
		 * if(true) {System.out.println("참"); 논리값 = false;}
		 * 
		 * // 조건식에 true를 입력하게 될 경우 무조건 값이 나옴
		 * 
		 * if (논리값) {System.out.println("논리값이 참이다.");}
		 */
		
		if(!논리값) {System.out.println("부정의 논리값");}
		// if는 보통 비교연산자 사용
	
		/*
		 * int a, b; a = 5; b = ++a;
		 * 
		 * System.out.println(a + " : " + b);
		 * 
		 * if(a == b) {System.out.println("a와 b는 같다");} else
		 * {System.out.println("a와 b는 다르다.");}
		 */
		/*
		if(!논리값) { // 거짓
			논리값 = !논리값;
			} 
		else if(논리값) { // 참
				System.out.println("참이다.");
				*/
		
		/*
		 * int a, b;
		 * 
		 * a = 10; b = 14;
		 * 
		 * if(!(a<b)) { System.out.println("B가 크다."); // 문제가 나올 땐 조건식 안에서만 생각하기 } else
		 * if(!(a>b)) { System.out.println("A가 크다.");}
		 * 
		 * 
		 * a = 5; b = 3;
		 * 
		 * if(a>b) {System.out.println("참");} if(a>=b) {System.out.println("참");}
		 * if(a<b) {System.out.println("거짓");} if(a<=b) {System.out.println("거짓");}
		 * if(a==b) {System.out.println("참");} if(a!=b) {System.out.println("거짓");}
		 */
	    
		// switch는 고정된 기능을 구현할 때 사용, 선택되어있는 기능 포함 
		// break를 쓰지 않으면 전부 다 실행됨 
				
		/*
		 * int a=1; 
		 * switch(a) {case 1:System.out.println("값이 1입니다."); break; 
		 * default:System.out.println("값이 1이 아닙니다.");}
		 */
					
		/*
		 * int a=2, b=5; 
		 * switch(a) {case 1:System.out.println("값이 5입니다"); break;
		 * default:System.out.println("값이 2입니다");}
		 */
				
				
		int a=3, b=4, c=5;
				
		switch (a+b+c){
		case 7:
			System.out.println("값이 7입니다.");
			break;
		default:
		 System.out.println("값이 12입니다.");
	}

}
}
