package Dbstudy;

public class S0527 {

	public static void main(String[] args) {
		
		// mariadb 접속
		new S0527_1().접속();
		// static은 메모리를 잡아먹기 때문에 개별 클래스 파일을 만들어 코드를 작성
		// 메인 메소드에는 실행하는 것만 적어두면됨
	}

}
