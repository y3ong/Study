package S0524;

public class Study03_2 extends Study03_1 {

	int a;
	
	Study03_2() {super(4);}
	
	Study03_2(int a){
		super.a = a; // 부모 변수를 찾기 위해 super 사용
	}
	
	void 함수2() {
		// 이 class 에 int a값이 없을 때 부모의 int a로 넘어가서 출력함
		
	}
}
