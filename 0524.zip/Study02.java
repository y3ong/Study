package S0524;

public class Study02 {
					
	public static void main(String[] args) {
		// static을 너무 많이 쓰게되면 메모리를 많이 쓰게 됨
		Study02_2 a = new Study02_2();
		
		a.함수();
		
	}

}
