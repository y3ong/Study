package S0524;

public class S0524_3 {

	static int a = 0;
	static int c = 0;
	
	public static void main(String[] args) {
	
		System.out.println(a);
		int c = b();
		System.out.println(c);
		

	}

	static int b() {
		int c = 5;
//		this.c = c; -> this를 사용할 수 있으나 static이 붙으면 사용 불가
		System.out.println(a);
		return c;
		
	}
	
	
	
}
