package S0524;

public class Study02_2 extends Study02_1 {
	// extends 쓰고 있는 클래스가 자식이 됨ㅋㅋ
	void 호출() { // method
		함수();
		
	}

//		void 함수() { // _1번이 가지고 있는거지만 메소드 재구성하였기 때문에 override 
//		System.out.println("함수111"); 내가 바꾸게 되는 순간 재구성되기 때문!!
//	}
	
	@Override // method 재구성
	void 함수2() {
	
		
	}
	
	void 함수2(int a) { //overload
		
	}
	
}
