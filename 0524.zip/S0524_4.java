package S0524;

public class S0524_4 {
	
	public static void main(String[] args) {
		
		// 메소드 > 함수형 : 호출(입력)     -> 반환(출력) ; 값을 전달
		// 클래스 > 객체형 : 생성자(인스턴스) -> 객체를 받는다 ; 객체 전달
		
		new S0524_5(); // <- 실행 or 호출
		S0524_5 s45 = new S0524_5(5);
		System.out.println(s45);
		s45.b();
		
	}

}
