package S0524;

public class Study01 {

	public static void main(String[] args) {
		
		new Study01_1().함수(); // new 키워드 사용하지 않고 메소드 실행하기 (static을 사용)
		// 변수든 메소드든 앞에 static 을 넣어서 new 키워드없이 함수처리 가능
		Study01_2.함수(); 
		System.out.println(Study01_2.a); 
		
		
	}

}
