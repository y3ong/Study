package S0524;

public class Study04_1 {

	
	Study04_1(int a, int b) {
		단(a, b);
		
// void 구구단(int a, int b){
//		단(a, b);}
		
	}

	// 구구단 만들기
	
 	private void 단(int a, int b) {
		
		for(; a <= b ; a++) {
			System.out.println(a+"단");
		 계산(a);
		 
			
		}
	}
	
	private void 계산(int a) {
		for(int i = 1; i <=9 ; i++) {
			System.out.println(a+"*"+i+"="+(a*i));
			
		}
		
	}
	
}
