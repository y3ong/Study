package S0524;

public class S0524_2 {

	public static void main(String[] args) {
		
		a();
		a(1);
		a("");
		
	}
	
	// 매개변수에 변수를 넣어 메소드 이름 동일하게 사용하게끔 만듦
	// overloading -> 
	// 전역변수 : class에서 만든 변수
	// 지역변수 : {} 중괄호 속에서 만든 변수, 다른 변수에서 사용 불가
	
	static void a() {
	}
	
	static void a(int a) {
	}
	
	static void a(String a) {
	}
	
}
