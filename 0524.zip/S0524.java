package S0524;

public class S0524 {

	public static void main(String[] args) {
		// public -> protected -> default -> private (접근제한 강화 순)

		// 메소드 : 함수형
		// 접근제어자 반환형 메소드명(전달값){
		//		명령문1
		//		명령문2
		//  }
		
		// 전달값 : 자바에서 매개변수라고 함
		// 반환형 : return 반환값; -> void (리턴하는 값이 없을 때)
		// 리턴타입이 필요할 때는 자료형을 씀
		// static 메모리 직접 할당함
		
		int 값1 = 합(1,2);
		// = : 대입, == : 비교
		System.out.println(값1);
		
		int 값2 = 빼기(1,2);
		System.out.println(값2);
		
		int 값3 = 나누기(1,2);
		System.out.println(값3);
		
		int 값4 = 곱하기(1,2);
		System.out.println(값4);
		
		
	}
	
	static int 합(int a, int b) {
		return (a + b);
	}
	
	static int 빼기(int a, int b) {
		return (a - b);	
		
	}
	static int 나누기(int a, int b) {
		return (a / b);
	}
	
	static int 곱하기(int a, int b) {
		return (a * b);
	}
		
		}
		
	


