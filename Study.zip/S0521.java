package Study;

public class S0521 {

	public static void main(String[] args) {
		
		
		int 단 = 1;
		while(단<10) {
			for(int 증가값 = 1; 증가값<10; 증가값++) {
//				 System.out.println(단 + "*" + 증가값 + "=" + (단 * 증가값));
				 }
			단++;
		}
		
		// 1차원 배열 (행) -> 표현 : [] / 행, 세로
		//  ex. 0  = 0 << 배열 [0] = 100;
		//      1
		//      2
		//		3
		
		int[] 배열 = new int[10]; // new 뒤에는 앞에 쓰였던 동일한 자료형을 적어야함
//		int 크기 = 배열.length; // length는 변수지만 내가 임의로 바꿀 수 없어 "상수"라고 함 
//		System.out.println(크기);
		
		// 배열[index] // 배열 뒤에 [] 붙는 이유는 공간을 사용하여 위치값을 생성하기 위함
		 배열[0] = 100; 
//		 System.out.println(배열[0]);
		 
		
		// 2차원 배열 -> 표현 : [행][열] 
		// [행0, 열0], [행0, 열1]
		// [행1, 열0], [행1, 열1]
		// [행2, 열0], [행2, 열1], [행2, 열2]
		
		 int[][] 배열2 = new int[5][3];
//		 int 세로크기 = 배열2.length; 
//		 int 가로크기 = 배열2[1].length;  // 열의 위치를 구할 때 []를 넣어야함
	
		 배열2[1][1]=5; // 배열 개수에 따라서 for 문 개수가 늘어남
		 System.out.println(배열2[1][1]); // 출력값 = 5
		 
	}

}
