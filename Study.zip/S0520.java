package Study;

public class S0520 {

	public static void main(String[] args) {
		
		/*********************************
		 * >>	반복문 for 
		 * for (선언;조건;증감) {명령문} 
		 / 명령문은 break, continue 사용 가능
	     *********************************/

		
		
	      // for 바깥에 변수 입력 시 전체 변수, () 안에 입력 시 for 문에만 해당되는 변수
		  // break; << break가 없을 경우 console에 멈추지 않고 출력되어 나옴
		  // for 문은 중첩이 가능 (for 안에 for 계속 사용 가능)
			
//			int tot = 0;
//			
//			for (int i = 1; i <= 10 ; i++ ) { // 어디에서 어디까지 조건식은 가운데에 입력 > i : 1 - 2 - 3 - 4 - 5 - 6 - 7 - 8 - 9 - 10
//			// index는 건드리면 안 됨, 증감 부분에서만 건드려야 틀리지 않음
//				System.out.println("전 : " + i);
//				tot = tot + i; // tot += i; 라고 해도 가능
//				System.out.println("후 : " + i);
//			}
//			
//			System.out.println("반복문의 합 : " + tot);
//			
//			
//			for (int i = 1; i <=10 ; i++) {
//				System.out.println(i);
				

			// Javastudy 오른쪽 마우스 클릭 -> Team -> Pull (첫번째)
		    // 오류났을 때,Team -> Show in history -> 오른쪽 마우스 -> Reset -> Hard ->
			
		
				
		// for (선언;조건;증감) {명령문}
		// 구구단
		// 단 * 증가값 = 결과값			

				
//			for (int 단=1; 단<=9 ; 단++) { // 단을 위한 반복문
//			 for (int 증가값 = 1; 증가값 <=9; 증가값++) { // 증가값을 위한 반복문 1~9
						 
				 // 출력 하는 곳
//				System.out.println(단 + "*" + 증가값 + "=" + (단 * 증가값));
//					 }
//				}
				
//			    int 단 = 1;
//				while(단 <=9) {
//				 단++;	}
					 
			

				// 문제1) 짝수 단수만 출력할 때
				
//				for (int 단=1; 단<=9 ; 단++) { // 단을 위한 반복문
					
//				 if( (단%2)==1) continue;
//				 if( (단%2)==0) { // 짝수
//			     if( (단%2)==0) { // 홀수
				 
//				   for (int 증가값 = 1; 증가값 <=9; 증가값++) { // 증가값을 위한 반복문 1~9
								 
				    // 출력 하는 곳						
//					System.out.println(단 + "*" + 증가값 + "=" + (단 * 증가값));
//					 }
//				}
//				}
			
				
				// 문제2) 한 줄에 단수를 3개 출력
		        // ln -> 줄 바꿈
				
//				for (int 단=1; 단<=9 ; 단+=3) { // 3단계식 반복
					
//					for (int 증가값=1; 증가값 <=9 ; 증가값++) { // 증가값 위한 반복문 1~9
						
//					System.out.print(단+"*"+증가값+"="+(단*증가값)+"\t"); // 1단
//					 int a = 단 + 1; // 2단, 단으로는 3단으로 바꿀 수 없기 때문에 변수를 설정
//					 int b = a + 1; // 3단
//					 System.out.print(a+"*"+증가값+"="+(a*증가값)+"\t");
//					 System.out.println(b+"*"+증가값+"="+(b*증가값)+"\t");
//					}
//			      System.out.println();
				
//				}
				
				// 문제3) 증가될 단수를 제어하세요.
//				int step = 3;
//				for (int 단=1; 단<=9 ; 단+=step) {// 3단계식 반복
				
//					for (int 증가값=1; 증가값 <=9 ; 증가값++) { // 증가값 위한 반복문 1~9
//						for (int s=단; s<(단+step) ;s++) {
//							System.out.print(s+"*"+증가값+"="+(s*증가값)+"\t");
//						}
//						  System.out.println();
//					}
//			      System.out.println();
//	}
		
		/*********************************
		 * >> do {} while();
		 *********************************/		
		
		// while 문은 참일 때만 실행
		int s = 0;
		int a = 4;
		while(s < a) { // true 자리에 조건 입력 (반복을 위한 코드이기 때문), 무한반복 명령어, 몇번 반복될 것인지
//			System.out.print(s+"\t");
//			System.out.print(a+"\t");
//			System.out.println(s >= a);
//			if(s >= a) break; // 검사 횟수, " <= " '이상'이기 때문에 4번 반복하고 싶다면 < 만 입력해야됨
			System.out.println("반복문");
			s++;
		}
		
		// do {} while(); do 먼저 실행 후 while 실행
		do {
			System.out.println("반복문");
			} while(a<s);
		
		
		
		int [] 정수형배열 = new int [8];
		
		정수형배열[2] = 5; // 배열로 for 문 실행 시 = 기호 사용하면 오류남
		
//		for(int i = 0;i<정수형배열.length;i++) {
//		System.out.println(정수형배열[i]);
//				}

		// 문제1) 인덱스 마지막에 10의 값을 넣고 마지막 인덱스만 출력하시오.
//		int s=정수형배열.length;
//		System.out.println(s);
		// index는 0부터 시작
		// 크기는 1부터 시작
		
		정수형배열[정수형배열.length-1] = 10;
		System.out.println(정수형배열[정수형배열.length-1]);
		
		
		int[][] 배열 = new int[4][5];
		
		배열[0][1] = 10;		
		배열[2][2] = 20;
		배열[3][3] = 30;
		
		for(int i = 0; i < 배열.length; i++) {
//		System.out.println(배열[i][i]);
			// 1 > [0][0]	= 0
			// 2 > [1][1]	= 1
			// 3 > [2][2]	= 2
			// 4 > [3][3]	= 3
			for(int j = 0; j < 배열[i].length; j++) {
				System.out.print(배열[i][j]+"\t");	
			
		
		// new << 객체를 생성하는 것을 의미
		
}
}
	}
	}
