package Study;

public class S0523_2 {

	public static void main(String[] args) {
		
		
//		배열 생성
//		[3행, 3열] 문자열 2차열 배열 생성 후
//		인덱스 [0행 0열] 부터 [2행, 2열]까지 차례대로 출력하시오.
//		(0, 0) (0, 1) (0, 2)
//		(1, 0) (1, 1) (1, 2)
//		(2, 0) (2, 1) (2, 2)

//		첫 번째, 문자열 배열을 생성한다.
//		String[][] 배열 = new String[3][3]; 

//		두 번째, for 문으로 행과 열을 돌립니다.
//		for (int i = 0; i < 배열.length; i++){
//		    for (int j = 0; j < 배열[i].length; j++) {
//		그리고, String 값 이라는 변수를 설정하여 출력한다.
//		    	String value = "(" + i + "," + j + ")"; 
//		    	System.out.print(value);
//		그리고 for 문 괄호 밖에서 줄바꿈을 위한 출력을 
//		진행한다.
//		    }
//		System.out.println();

//	}
		
//		int a, b; 
//		a=0 ; b=5;
//		
//		if (!(a > b)) {
//		    System.out.println("B가 크다.");
//		} 

//	원인 :
// 	b가 더 크기 때문에
//	해결 방안 : 
// 	if문 조건식을 (!(a>b)) 으로 변경하여 처리한다. 


		int k = 16;
        int[][] arr = new int[4][4];
        for(int i= 0; i < arr.length ; i++) {
            for(int j=0; j > arr[i].length ; j++) {
                arr[i][j] = k;
                k--;
                System.out.print(arr[i][j] + ",\t");
            }
            System.out.println();
        }

//	원인 :
//  2번째 포문에서 변수 j는 배열 arr의 열인덱스를 표현하므로 arr[i].length보다 클수 없다. 
//	해결방안 :
//	조건식 : j> arr[i].length 를 j < arr[i].length로 변경 한다. 


		
}
}

