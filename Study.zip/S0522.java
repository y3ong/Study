package Study;

public class S0522 {

	public class Test05223 {

		public static void main(String[] args) {
			
//			Scanner a = new Scanner(System.in); // 프로그램 실행 시 입력값을 받기 위해 사용
//			boolean key = false;
//			
//			while(true) { // switch를 계속 반복할 수 있게 도와줌
//				
//				System.out.println("1~4 정수의 값을 입력하세요.");
//				int 입력값 = a.nextInt(); // 반환값, console에 입력해야 값이 나옴
//			
//				switch (입력값) { 
//					case 1: System.out.println("값이 1입니다."); 
//					break; 
//					case 2: System.out.println("값이 2입니다."); 
//					break; 
//					case 3: System.out.println("값이 3입니다."); 
//					break; 
//					case 4: System.out.println("값이 4입니다."); 
//					break; 
//					default:
//						System.out.println("잘못된 값입니다."); 
//					key = true;
//				}
//				if(key) break;
//				
//			}
			
			
//			if(입력값 == 0) {
//				System.out.println("0을 입력하셨습니다.");
//			}
//			if(입력값 == 1) {
//				System.out.println("1을 입력하셨습니다.");
//			}
//			if(입력값 == 2) {
//				System.out.println("2을 입력하셨습니다.");	
//			}
//			if(입력값 == 3) {
//				System.out.println("3을 입력하셨습니다.");	
//			}

			
			
			int sum = 0;
			int[] number = {2,4,6,8,10};
			
			for(int i = 0; i<= number.length; i++) {
			sum += number[i];
			
		}
			System.out.println("numbers배열 요소의 합 : " + sum);
			
	}
	}
}

