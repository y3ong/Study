package Study;

import java.util.Scanner;

/*********************************
 * >> Console 입력 알아보기
 * Scanner 클래스의 라이프 사이클
 *********************************/

public class S0523_1 {

	public static void main(String[] args) {

		/** 객체 생성 **/
//		Scanner sc = new Scanner(System.in);
		// 외부 장비를 연결시켜주는 하나의 객체
		// 함수형, method라고 부름
		
		
		/** 객체 사용 **/
//		int a = sc.nextInt();
//		System.out.println(a);
		
		
		/** 객체 제거 **/
//		sc.close();
		// close 실행어를 넣지 않으면 계속 대기상태로 메모리를 잡아먹음
		// close 밑에 명령어를 작성해도 사용할 수 없음 (오류생김)
		// 단일 프로그램은 close 실행어가 없어도 종료되어 작성하지 않아도 됨
		
//		int b = sc.nextInt();
//		System.out.println(b);
		
		
		
/*********************************
 * >> Console 입력 알아보기
 * Scanner 클래스를 이용하여 간단한 연산하기
*********************************/
		

		/** 객체 생성 **/
//		Scanner sc = new Scanner(System.in);
				
		/** 객체 사용 **/
		
//		int a = sc.nextInt();
//		int b = sc.nextInt();
//		
//		System.out.println(a+b);
	
		
				
		/** 객체 제거 **/
//		sc.close();
		
		
/*********************************
 * >> Console 입력 알아보기
 * Scanner 클래스를 이용하여 반복문를 멈추기
*********************************/
		
		/** 객체 생성 **/
//		Scanner sc = new Scanner(System.in);
		
		/** 객체 사용 **/
//		while(true) {
//			String key = sc.nextLine();
//			if("STOP".equals(key)) break;
//			// 기준은 앞에, 변수는 뒤에 적는게 기본
			
//		}
		
		
		/** 객체 제거 **/
//		sc.close();
		
		
/*********************************
 * >> Console 입력 알아보기
 * Scanner 클래스를 이용하여 설문조사 하기
*********************************/		
		
		/** 객체 생성 **/
//		Scanner sc = new Scanner(System.in);
		
		/** 객체 사용 **/
		// 배열과 반복문을 사용
		// 마지막에 for 문을 사용하여 출력
		

//		while(true) {
//			
//			System.out.println("당신의 나이대는?");
//			String key = sc.nextLine();
//			
//			if ("10".equals(key)) {
//				System.out.println("10대입니다."); 
//			} else if ("20".equals(key)) {
//				System.out.println("20대입니다."); 
//			} else if ("30".equals(key)) {
//				System.out.println("30대입니다.");
//			} else if ("40".equals(key)) {
//				System.out.println("40대입니다.");
//			} else if ("50".equals(key)) {
//				System.out.println("50대입니다.");
//			} else if ("60".equals(key)) {
//				System.out.println("60대입니다.");
//			} else if ("70".equals(key)) {
//				System.out.println("70대입니다.");
//			} else {System.out.println("80대입니다."); 
//				break;
//				}
//			}
		
		
//		String q1 = "당신의 이름은?";
//		String q2 = "당신의 나이는?";
//		String q3 = "당신의 직업은?";
		
//		String[] 질문1 = new String[] {q1,q2,q3};
//		
//		for(int i=0;i<질문1.length;i++) {
//		System.out.println(질문1[i]);
//		System.out.println(sc.nextLine());
//		}
		
//		String[][] 질문2 = new String[][] {{q1, ""},{q2, ""},{q3, ""}};
//		
//		for(int i=0; i<질문2.length; i++) {
//			System.out.println(질문2[i][0]);
//			String 답변 = sc.nextLine();
//			질문2[i][1]= 답변;
//		}
//		
//		for(int i=0; i<질문2.length;i++) {
//			System.out.print(질문2[i][0]);
//			System.out.println("\t"+질문2[i][1]);
//		}
		
		/** 객체 제거 **/
//		sc.close();
		
/*********************************
 * >> Console 입력 알아보기
 * Scanner 클래스와 반복문를 이용하여 계산기 만들기
 *********************************/
		
		/** 객체 생성 **/
		Scanner sc = new Scanner(System.in);
		
		/** 객체 사용 **/
		String 더하기 = "+";
		String 빼기 = "-";
		String 곱하기 = "*";
		String 나누기 = "/";
		
		while(true) {
			System.out.println("첫번째 숫자를 입력하세요.");
			int a = sc.nextInt();
			System.out.println("+,-,*,/ 중 연산자를 입력하세요.");
			String b = sc.next();
			System.out.println("두번째 숫자를 입력하세요.");
			int c = sc.nextInt();
			
			// nextLine() 오류 원인
			// nextLine() 썼을때 오류가 났었던 원인은 nextLine()은 Enter 키를 문자로 인지
			// nextInt()는 숫자만 입력하기때문에 Enter 값이 존재
			// Enter 값을 nextLine()에서 먼저 받아가기 때문에
			// 연산 기호를 입력 받지 않고 다음 단계를 실행한다.
			//next()는 구분자를 남겨두고 nextLine()은 구분자를 떼고 넘겨주는 것을 알게 되었다

			//해결 방법
			//next()를 사용하거나 연산기호를 입력 받기전에 nextLine()를 한번 사용하여
			//Enter값을 빼준다.
			
			
			String d = "";
			switch(b) {
			case "+" : d = a+ 더하기 + c + "=" + (a+c);
				break;
			case "-" : d = a+ 빼기 + c + "=" + (a-c);
				break;
			case "*" : d = a+ 곱하기 + c + "=" + (a/c);
				break;
			case "/" : d = a+ 나누기 + c + "=" + (a*c);
				break;
			default:
				
			}
			
			System.out.println(d);
		
		}
		
//		while(true) {
//		
//		System.out.print("정수 입력 :");
//		int num1 = sc.nextInt();
//		System.out.print("다음 정수 입력 : ");
//		int num2 = sc.nextInt();
//		System.out.print("[1]더하기 [2]뺴기 [3]곱하기 [4]나누기");
//		int ca = sc.nextInt();
//	
//		if(ca == 1) {
//		System.out.println(num1 + num2);
//		} else if(ca == 2) {
//			System.out.println(num1 - num2);
//		} else if(ca == 3) {
//			System.out.println(num1 * num2);
//		} else if(ca == 4) {
//			System.out.println(num1 / num2);
//		} else {
//			System.out.println("잘못 입력되었습니다.");
//		} break;
//	}
		
		
		
		/** 객체 제거 **/
		//sc.close();
		
	}

}
