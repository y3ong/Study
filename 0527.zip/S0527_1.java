package Study;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class S0527_1 {
	
	String 주소 = "jdbc:mariadb://localhost:3306/ye"; // JDBC 주소값 입력
	String 사용자 = "root";
	String 비밀번호 = "1004";

	public void 접속() {
		System.out.println("접속 시작!");
		String driver = "org.mariadb.jdbc.Driver";
		try { // 외부 라이브러리를 가져오기 위한 try catch
			
			Class.forName(driver); // 라이브러리 존재 확인
//			System.out.println("드라이버 클래스 존재합니다.");
			
			// 데이터베이스 접속
			// 기본 format : jdbc > database type > host(IP) > port > database ID
			//	ex. 		jdbc   oracle:thin:  @//[HOST]  [:PORT]  /SERVICE
			
			Connection conn = DriverManager.getConnection(주소, 사용자, 비밀번호);
			
			String sql1 = "create OR REPLACE table test (no int, name varchar(50))";
			// Create [or replace] -table-tbl_name
			// DDL Create 과정
			PreparedStatement ps = conn.prepareStatement(sql1);
			ps.execute(); // 자료를 보관하기 위한 테이블 생성
			
			String sql2 = "insert into test (name, no) value ('하이', 1)";
			// 대상 테이블이 존재해야 insert 문을 완성할 수 있음
			
			ps = conn.prepareStatement(sql2);
			int result = ps.executeUpdate();
			System.out.println(result);
			
			// sq1 = select문 실행해서 위의 insert된 데이터를 출력하시오.
			String sql3 = "select * from test";
			
			ps = conn.prepareStatement(sql3);
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				int no = rs.getInt("no");
				String name = rs.getString("name");
				TestDTO testDto = new TestDTO();
				testDto.setNo(no);
				testDto.setName(name);
				System.out.println(testDto);
//				System.out.println(no+","+name);
			}
			
			// 수정
			String sql4 = "update test set name = '안녕'";		
			ps = conn.prepareStatement(sql4);
			result = ps.executeUpdate();
			System.out.println(result);
			
			// 데이터 확인
			ps = conn.prepareStatement(sql3);
			rs = ps.executeQuery();
			
			while(rs.next()) {
				int no = rs.getInt("no");
				String name = rs.getString("name");
				TestDTO testDto = new TestDTO();
				testDto.setNo(no);
				testDto.setName(name);
				System.out.println(testDto);
			}
			
			// 데이터 확인
			
			// 삭제
			String sql5 = "delete from test";
			ps = conn.prepareStatement(sql5);
			result = ps.executeUpdate();
			System.out.println(result);
			
			ps = conn.prepareStatement(sql3);
			rs = ps.executeQuery();
			int cnt = 0;
			while(rs.next()) {
				int no = rs.getInt("no");
				String name = rs.getString("name");
				TestDTO testDto = new TestDTO();
				testDto.setNo(no);
				testDto.setName(name);
				System.out.println(testDto);
				cnt++;
			}
			System.out.println("행수 : "+cnt);
			conn.close(); // scanner와 동일함, 생성-종료 과정 필요
//			System.out.println("섹션 생성 완료!");
			
		} catch(ClassNotFoundException e) { // class 여부에 대한 catch
			e.printStackTrace();
		} catch (SQLException e) { // 데이터베이스에 대한 catch
			e.printStackTrace();
		}
	}
	
}


